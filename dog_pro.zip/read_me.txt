_wrangle_act.ipynb: code for gathering, assessing, cleaning, analyzing, and visualizing data

_wrangle_report.pdf or wrangle_report.html: documentation for data wrangling steps: gather, assess, and clean

_act_report.pdf or act_report.html: documentation of analysis and insights into final data
_twitter_archive_enhanced.csv: file as given

_image_predictions.tsv: file downloaded programmatically

_tweet_json.txt: file constructed via API

_twitter_archive_master.csv: combined and cleaned data